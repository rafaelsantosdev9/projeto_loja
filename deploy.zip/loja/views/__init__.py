#import das outras views aqui
from .loja_views import *